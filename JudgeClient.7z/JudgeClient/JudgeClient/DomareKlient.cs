﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JudgeClient
{
    
    public partial class JudgeClient : Form
    {
        public bool myBool;
        public JudgeClient()
        {
            InitializeComponent();
        }

        private void TrackBarPoints_Scroll(object sender, EventArgs e)
        {
            float value = TrackBarPoints.Value / 2f;
            ValueLabel.Text = value.ToString("0.00");
        }

        private void JudgeChatGroup_Enter(object sender, EventArgs e)
        {
           
        }

        private void JudgeChatButton_Click(object sender, EventArgs e)
        {
            myBool = !myBool;

            if (myBool == true)
            {
                JudgeChatGroup.Visible = true;
            }
            else if(myBool == false)
            {
                JudgeChatGroup.Visible = false;
            }

        }

    }
}


           
