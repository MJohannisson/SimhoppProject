﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleTCP;

namespace JudgeClient
{
    //public delegate void sendPoint(VoteButton_Click());
    public partial class JudgeClient : Form
    {
        public List<ReadParticipant> NewReadParticipants;
        List<string> msgList = new List<string>();
        private int judge = 0;
        private int participant = 0;
        public bool myBool;
        public TCP_Connect myConnection;
        public JudgeClient(TCP_Connect newConnection)
        {
            InitializeComponent();
            myConnection = newConnection;
            DBtoReadParticipant dbRead = new DBtoReadParticipant();
            NewReadParticipants = dbRead.ReadParticipant();
            this.FornamnEfternamnLabel.Text = NewReadParticipants[0].FirstName + " " + NewReadParticipants[0].LastName;
            this.JumpStyleLabel.Text = NewReadParticipants[0].Jumpstyle;
            this.HeightLabel.Text = NewReadParticipants[0].Height.ToString();
            this.CurrentJudgeLable.Text = (this.judge+1).ToString();

        }
        private void TrackBarPoints_Scroll(object sender, EventArgs e)
        {
            float value = TrackBarPoints.Value / 2f;
            ValueLabel.Text = value.ToString("0.00");
        }

        private void JudgeChatGroup_Enter(object sender, EventArgs e)
        {
           
        }

        private void JudgeChatButton_Click(object sender, EventArgs e)
        {
            myBool = !myBool;

            if (myBool == true)
            {
                JudgeChatGroup.Visible = true;
            }
            else if(myBool == false)
            {
                JudgeChatGroup.Visible = false;
            }
        }

        private void VoteButton_Click(object sender, EventArgs e/*, sendPoint sendPoint*/)
        {
            //myConnection.getstr(this.participant, this.judge, this.ValueLabel.Text);
            //if (participant > NewReadParticipants.Count())
            //{
            //    MessageBox.Show("Denna session är avslutat, tack för din insats");
            //    this.Close();
            //
            //}
            myConnection.getstrChat("p " + this.participant.ToString() + " " + this.judge.ToString() + " " + this.ValueLabel.Text+" ");//new try
            //this.judge = this.judge + 1;                                                                                                                        //
            //this.judge++;
            this.judge = this.judge + 1;
            this.CurrentJudgeLable.Text = (this.judge).ToString();
            if (this.judge == 5/*6*/)
            {
                this.participant = this.participant + 1;
                //this.participant = participant++;
                this.judge = 0;

                if (participant >= NewReadParticipants.Count())
                {
                    MessageBox.Show("Denna session är avslutat, tack för din insats");
                    this.Close();
                    this.Enabled = false;
                }
                else
                {
                    this.FornamnEfternamnLabel.Text = NewReadParticipants[participant].FirstName + " " + NewReadParticipants[participant].LastName;
                    this.JumpStyleLabel.Text = NewReadParticipants[participant].Jumpstyle;
                    this.HeightLabel.Text = NewReadParticipants[participant].Height.ToString();

                } 
                
            }

        }

        private void SendButton_Click(object sender, EventArgs e)
        {
            myConnection.getstrChat("c "+ this.TextBoxMessage.Text);
            this.TextBoxMessage.Text = "";
        }

        private void TextDisplayRichTextBox_TextChanged(object sender, EventArgs e)
        {
            while (myConnection.IncMessage() != "")
            {
                string newmsg = myConnection.IncMessage();
                msgList.Add(newmsg);
                foreach (string s in msgList)
                {
                    this.TextDisplayRichTextBox.AppendText("\n" + s);
                }
            }


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}