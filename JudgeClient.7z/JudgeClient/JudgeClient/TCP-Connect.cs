﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.Data.SqlClient;
using System.IO;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.ServiceModel.Security;
using System.Windows.Forms;
using System.Threading;

namespace JudgeClient
{
    public class TCP_Connect
    {
        private static readonly Socket ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        private const int BUFFER_SIZE = 2048;
        private const int PORT = 100;
        private static readonly byte[] buffer = new byte[BUFFER_SIZE];
        IPHostEntry ipHostInfo;
        IPAddress ipAddress;
        IPEndPoint localEndPoint;//GÖR CLIENT SOCKET
        string ip;
        private Thread rxThread = null;
        public TCP_Connect()
        {
            //Console.Title = "Client";
            var recievedData = "";
            var con = new SqlConnection("Data Source=simhoppdb.database.windows.net;Initial Catalog=SimHopp;Persist Security Info=True;User ID=SIMHOPP;Password=10helluworlD");
            con.Open();
            var cmd = new SqlCommand("SELECT * From IPAddresser", con);
            cmd.ExecuteNonQuery();
            SqlDataReader myreader;
            try
            {
                myreader = cmd.ExecuteReader();
                if (myreader.Read())//while
                {
                    recievedData = myreader.GetString(0);
                    //Console.WriteLine(recievedData);
                }

            }
            catch (Exception ex)
            {
                //Console.WriteLine("Fail");
            }
            //Console.Read();
            con.Close();
            var ipHostInfo = Dns.Resolve(recievedData);
            var ipAddress = ipHostInfo.AddressList[0];
            var localEndPoint = new IPEndPoint(ipAddress, 11000);
            var ip = ipHostInfo.AddressList[0].ToString();
            ConnectToServer(recievedData);


            rxThread = new Thread(RequestLoop);
            rxThread.Start();
            //RequestLoop();
            //Exit();
        }
        private static void ConnectToServer(string IPAddress)
        {
            //int attempts = 0;

            //IPHostEntry ipHostInfo = Dns.GetHostEntry("10.22.16.88");
            //IPAddress ipAddress = ipHostInfo.AddressList[0];
            //IPEndPoint remoteEP = new IPEndPoint(ipAddress, /*11000*/PORT);


            while (!ClientSocket.Connected)
            {
                try
                {
                    //attempts++;
                    //Console.WriteLine("Connection attempt " + attempts);
                    //IPAddress newIP = new IPAddress(13024396164);
                    ClientSocket.Connect(/*IPAddress.Loopback*//*"130,243,96,164"*//*"10.22.16.88"*/IPAddress, PORT/*7702*/);
                    //ClientSocket.Connect(remoteEP);
                }
                catch (SocketException)
                {
                    //Console.Clear();
                }
            }
            //Console.Clear();
            //Console.WriteLine("Connected");
        }

        public StreamReader sr = null;
        private/*static*/ void RequestLoop()
        {
            //Console.WriteLine(@"<Type ""exit"" to properly disconnect client>");
            //sendPoint newPoint = new sendPoint();
            //byte[] Response  = new byte[2048];
            //sr = new StreamReader(ClientSocket.Receive(Response());
            //int byteReceive = ClientSocket.Receive(Response);
            var ns = new NetworkStream(ClientSocket);
            sr = new StreamReader(ns);

            while (true)
            {
                var response = sr.ReadLine();
                Console.WriteLine(response);
                //SendRequest();
                // ReceiveResponse();
            }
        }

        /// <summary>
        /// Close socket and exit program.
        /// </summary>
        private static void Exit()
        {
            SendString("exit");
            ClientSocket.Shutdown(SocketShutdown.Both);
            ClientSocket.Close();
            Environment.Exit(0);
        }
        

        //private static void SendRequest(string text)
        //{
        //    //Console.Write("Send a request: ");
        //    //string request = Console.ReadLine();
        //    SendString(text);
        //
        //    if (text.ToLower() == "exit")
        //    {
        //        Exit();
        //    }
        //}
        public void getstr(int participantID, int judgeID, string newstr)
        {
            var info = participantID + " " + judgeID + " " + newstr;
            SendString(info);
        }
        public void getstrChat(string message)
        {
            SendString(message);
        }
        public static void SendString(string text)
        {
            if (text.ToLower() == "exit")
            {
                Exit();
            }
            var buffer = Encoding.ASCII.GetBytes(text);
            ClientSocket.Send(buffer, 0, buffer.Length, SocketFlags.None);
        }

        private static void ReceiveResponse()
        {
           //var buffer = new byte[2048];
           //int received = ClientSocket.Receive(buffer, SocketFlags.None);
           //if (received == 0) return;
           //var data = new byte[received];
           //Array.Copy(buffer, data, received);
           //string text = Encoding.ASCII.GetString(data);
            //Console.WriteLine(text);
        }
        public string IncMessage()
        {
            try
            {
                while (true)
                {
                    var buffer = new byte[2048];
                    ClientSocket.Receive(buffer, 0, buffer.Length, 0);
                    var message = Encoding.UTF8.GetString(buffer);
                    return message;
                }
            }
            catch
            {
                return "";
            }
        }
    }
    }

