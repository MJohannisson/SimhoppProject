﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JudgeClient
{
   public class ReadParticipant
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Country { get; set; }
        public string Gender { get; set; }
        public string Jumpstyle { get; set; }
        public float Height { get; set; }
        //public int Attempt { get; set; }

        public ReadParticipant(int id, string firstName, string lastName, string country, string gender,
            string jumpstyle)
        {
            this.ID = id;
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Country = country;
            this.Gender = gender;
            this.Jumpstyle = jumpstyle.Substring(0,4);
            this.Height = float.Parse(jumpstyle.Remove(0,4));
        }
    }
}