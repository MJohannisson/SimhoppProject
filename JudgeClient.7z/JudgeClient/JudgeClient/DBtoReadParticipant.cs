﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace JudgeClient
{

    class DBtoReadParticipant
    {
        private SqlConnection con;
        public DBtoReadParticipant()
        {
            this.con = new SqlConnection("Data Source=simhoppdb.database.windows.net;Initial Catalog=SimHopp;Persist Security Info=True;User ID=SIMHOPP;Password=10helluworlD");
        }

        public List<ReadParticipant> ReadParticipant()
        {
            con.Open();
           
            List<ReadParticipant> l1 = new List<ReadParticipant>();
            //SqlCommand cmd = new SqlCommand("SELECT Participant.ID, Participant.FirstName,Participant.LastName, Participant.Gender, Participant.Country, Record_Of_Jumps.RefCode from Participant, Record_Of_Jumps;", con);
            SqlCommand cmd = new SqlCommand("SELECT Participant.ID, Participant.FirstName,Participant.LastName, Participant.Gender, Participant.Country, Record_Of_Jumps.RefCode FROM Participant INNER JOIN Record_Of_Jumps ON Record_Of_Jumps.IDParticipant = Participant.ID;", con);
            //cmd.ExecuteNonQuery();
            SqlDataReader myreader;
            try
            {

                myreader = cmd.ExecuteReader();
                //MessageBox.Show("Sparad");
                while (myreader.Read())
                {
                    //ReadParticipant db = new ReadParticipant(myreader.GetInt32(0), myreader.GetString(1), myreader.GetString(2),
                    //    myreader.GetString(3), myreader.GetString(4), myreader.GetString(5));
                    //l1.Add(db);
                    l1.Add(new ReadParticipant(myreader.GetInt32(0), myreader.GetString(1), myreader.GetString(2),
                        myreader.GetString(3), myreader.GetString(4), myreader.GetString(5)));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            con.Close();
            return l1;
        }
    }       
}
