﻿namespace JudgeClient
{
    partial class JudgeClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TopPanel = new System.Windows.Forms.Panel();
            this.TrackBarPoints = new System.Windows.Forms.TrackBar();
            this.Points = new System.Windows.Forms.Label();
            this.ValueLabel = new System.Windows.Forms.Label();
            this.VoteButton = new System.Windows.Forms.Button();
            this.FornamnEfternamnLabel = new System.Windows.Forms.Label();
            this.JumpStyleLabel = new System.Windows.Forms.Label();
            this.HeightLabel = new System.Windows.Forms.Label();
            this.NrOfJumpLabel = new System.Windows.Forms.Label();
            this.JudgeChatGroup = new System.Windows.Forms.GroupBox();
            this.JudgeChatButton = new System.Windows.Forms.Button();
            this.TextDisplayRichTextBox = new System.Windows.Forms.RichTextBox();
            this.TextBoxMessage = new System.Windows.Forms.TextBox();
            this.SendButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarPoints)).BeginInit();
            this.JudgeChatGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // TopPanel
            // 
            this.TopPanel.BackColor = System.Drawing.SystemColors.Highlight;
            this.TopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.TopPanel.Location = new System.Drawing.Point(0, 0);
            this.TopPanel.Name = "TopPanel";
            this.TopPanel.Size = new System.Drawing.Size(1906, 44);
            this.TopPanel.TabIndex = 0;
            // 
            // TrackBarPoints
            // 
            this.TrackBarPoints.Location = new System.Drawing.Point(592, 606);
            this.TrackBarPoints.Maximum = 20;
            this.TrackBarPoints.Name = "TrackBarPoints";
            this.TrackBarPoints.Size = new System.Drawing.Size(676, 69);
            this.TrackBarPoints.TabIndex = 1;
            this.TrackBarPoints.Value = 2;
            this.TrackBarPoints.Scroll += new System.EventHandler(this.TrackBarPoints_Scroll);
            // 
            // Points
            // 
            this.Points.AutoSize = true;
            this.Points.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Points.Location = new System.Drawing.Point(684, 527);
            this.Points.Name = "Points";
            this.Points.Size = new System.Drawing.Size(89, 29);
            this.Points.TabIndex = 2;
            this.Points.Text = "Poäng:";
            // 
            // ValueLabel
            // 
            this.ValueLabel.AutoSize = true;
            this.ValueLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValueLabel.Location = new System.Drawing.Point(779, 527);
            this.ValueLabel.Name = "ValueLabel";
            this.ValueLabel.Size = new System.Drawing.Size(26, 29);
            this.ValueLabel.TabIndex = 3;
            this.ValueLabel.Text = "0";
            // 
            // VoteButton
            // 
            this.VoteButton.Location = new System.Drawing.Point(610, 695);
            this.VoteButton.Name = "VoteButton";
            this.VoteButton.Size = new System.Drawing.Size(645, 58);
            this.VoteButton.TabIndex = 4;
            this.VoteButton.Text = "Rösta";
            this.VoteButton.UseVisualStyleBackColor = true;
            // 
            // FornamnEfternamnLabel
            // 
            this.FornamnEfternamnLabel.AutoSize = true;
            this.FornamnEfternamnLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FornamnEfternamnLabel.Location = new System.Drawing.Point(777, 239);
            this.FornamnEfternamnLabel.Name = "FornamnEfternamnLabel";
            this.FornamnEfternamnLabel.Size = new System.Drawing.Size(304, 37);
            this.FornamnEfternamnLabel.TabIndex = 5;
            this.FornamnEfternamnLabel.Text = "Förnamn Efternamn";
            // 
            // JumpStyleLabel
            // 
            this.JumpStyleLabel.AutoSize = true;
            this.JumpStyleLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JumpStyleLabel.Location = new System.Drawing.Point(702, 314);
            this.JumpStyleLabel.Name = "JumpStyleLabel";
            this.JumpStyleLabel.Size = new System.Drawing.Size(103, 29);
            this.JumpStyleLabel.TabIndex = 6;
            this.JumpStyleLabel.Text = "Hopptyp";
            // 
            // HeightLabel
            // 
            this.HeightLabel.AutoSize = true;
            this.HeightLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HeightLabel.Location = new System.Drawing.Point(889, 314);
            this.HeightLabel.Name = "HeightLabel";
            this.HeightLabel.Size = new System.Drawing.Size(64, 29);
            this.HeightLabel.TabIndex = 7;
            this.HeightLabel.Text = "Höjd";
            // 
            // NrOfJumpLabel
            // 
            this.NrOfJumpLabel.AutoSize = true;
            this.NrOfJumpLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NrOfJumpLabel.Location = new System.Drawing.Point(1029, 314);
            this.NrOfJumpLabel.Name = "NrOfJumpLabel";
            this.NrOfJumpLabel.Size = new System.Drawing.Size(134, 29);
            this.NrOfJumpLabel.TabIndex = 8;
            this.NrOfJumpLabel.Text = "Nr av Hopp";
            // 
            // JudgeChatGroup
            // 
            this.JudgeChatGroup.Controls.Add(this.SendButton);
            this.JudgeChatGroup.Controls.Add(this.TextBoxMessage);
            this.JudgeChatGroup.Controls.Add(this.TextDisplayRichTextBox);
            this.JudgeChatGroup.Location = new System.Drawing.Point(1460, 314);
            this.JudgeChatGroup.Name = "JudgeChatGroup";
            this.JudgeChatGroup.Size = new System.Drawing.Size(418, 647);
            this.JudgeChatGroup.TabIndex = 9;
            this.JudgeChatGroup.TabStop = false;
            this.JudgeChatGroup.Text = "Chat";
            this.JudgeChatGroup.Visible = false;
            this.JudgeChatGroup.Enter += new System.EventHandler(this.JudgeChatGroup_Enter);
            // 
            // JudgeChatButton
            // 
            this.JudgeChatButton.Location = new System.Drawing.Point(1776, 967);
            this.JudgeChatButton.Name = "JudgeChatButton";
            this.JudgeChatButton.Size = new System.Drawing.Size(102, 72);
            this.JudgeChatButton.TabIndex = 10;
            this.JudgeChatButton.Text = "Chat";
            this.JudgeChatButton.UseVisualStyleBackColor = true;
            this.JudgeChatButton.Click += new System.EventHandler(this.JudgeChatButton_Click);
            // 
            // TextDisplayRichTextBox
            // 
            this.TextDisplayRichTextBox.Dock = System.Windows.Forms.DockStyle.Top;
            this.TextDisplayRichTextBox.Location = new System.Drawing.Point(3, 22);
            this.TextDisplayRichTextBox.Name = "TextDisplayRichTextBox";
            this.TextDisplayRichTextBox.Size = new System.Drawing.Size(412, 513);
            this.TextDisplayRichTextBox.TabIndex = 11;
            this.TextDisplayRichTextBox.Text = "";
            // 
            // TextBoxMessage
            // 
            this.TextBoxMessage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TextBoxMessage.Location = new System.Drawing.Point(3, 535);
            this.TextBoxMessage.Name = "TextBoxMessage";
            this.TextBoxMessage.Size = new System.Drawing.Size(412, 26);
            this.TextBoxMessage.TabIndex = 12;
            // 
            // SendButton
            // 
            this.SendButton.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.SendButton.Location = new System.Drawing.Point(3, 603);
            this.SendButton.Name = "SendButton";
            this.SendButton.Size = new System.Drawing.Size(412, 41);
            this.SendButton.TabIndex = 13;
            this.SendButton.Text = "Skicka";
            this.SendButton.UseVisualStyleBackColor = true;
            // 
            // JudgeClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1906, 1051);
            this.Controls.Add(this.JudgeChatButton);
            this.Controls.Add(this.JudgeChatGroup);
            this.Controls.Add(this.NrOfJumpLabel);
            this.Controls.Add(this.HeightLabel);
            this.Controls.Add(this.JumpStyleLabel);
            this.Controls.Add(this.FornamnEfternamnLabel);
            this.Controls.Add(this.VoteButton);
            this.Controls.Add(this.ValueLabel);
            this.Controls.Add(this.Points);
            this.Controls.Add(this.TrackBarPoints);
            this.Controls.Add(this.TopPanel);
            this.Name = "JudgeClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Domare";
            ((System.ComponentModel.ISupportInitialize)(this.TrackBarPoints)).EndInit();
            this.JudgeChatGroup.ResumeLayout(false);
            this.JudgeChatGroup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel TopPanel;
        private System.Windows.Forms.TrackBar TrackBarPoints;
        private System.Windows.Forms.Label Points;
        private System.Windows.Forms.Label ValueLabel;
        private System.Windows.Forms.Button VoteButton;
        private System.Windows.Forms.Label FornamnEfternamnLabel;
        private System.Windows.Forms.Label JumpStyleLabel;
        private System.Windows.Forms.Label HeightLabel;
        private System.Windows.Forms.Label NrOfJumpLabel;
        private System.Windows.Forms.GroupBox JudgeChatGroup;
        private System.Windows.Forms.Button JudgeChatButton;
        private System.Windows.Forms.Button SendButton;
        private System.Windows.Forms.TextBox TextBoxMessage;
        private System.Windows.Forms.RichTextBox TextDisplayRichTextBox;
    }
}

