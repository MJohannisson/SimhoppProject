﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;  

namespace ChattingServer
{
    class Program
    {
        public static ChattingService _service;
        static void Main(string[] args)
        {
            _service = new ChattingService();
            using (ServiceHost host = new ServiceHost(_service))
            {
                host.Open();
                Console.WriteLine("Server is running...");
                Console.ReadLine();
            }
        }
    }
}
